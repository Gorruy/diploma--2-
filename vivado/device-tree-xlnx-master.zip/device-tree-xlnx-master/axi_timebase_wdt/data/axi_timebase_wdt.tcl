#
# (C) Copyright 2014-2022 Xilinx, Inc.
# (C) Copyright 2022 Advanced Micro Devices, Inc. All Rights Reserved.
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License as
# published by the Free Software Foundation; either version 2 of
# the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#

proc generate {drv_handle} {
	# try to source the common tcl procs
	# assuming the order of return is based on repo priority
	foreach i [get_sw_cores device_tree] {
		set common_tcl_file "[get_property "REPOSITORY" $i]/data/common_proc.tcl"
		if {[file exists $common_tcl_file]} {
			source $common_tcl_file
			break
		}
	}
	set compatible [get_comp_str $drv_handle]
	set compatible [append compatible " " "xlnx,xps-timebase-wdt-1.00.a"]
	set_drv_prop $drv_handle compatible "$compatible" stringlist
	# get bus clock frequency
	set clk_freq [get_clock_frequency [get_cells -hier $drv_handle] "S_AXI_ACLK"]
	if {![string equal $clk_freq ""]} {
		set_property CONFIG.clock-frequency $clk_freq $drv_handle
	}
	set_drv_conf_prop $drv_handle "C_WDT_ENABLE_ONCE" "xlnx,wdt-enable-once"
	set_drv_conf_prop $drv_handle "C_WDT_INTERVAL" "xlnx,wdt-interval"

}

